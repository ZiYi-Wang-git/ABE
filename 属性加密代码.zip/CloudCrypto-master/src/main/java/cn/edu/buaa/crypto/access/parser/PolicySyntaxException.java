package cn.edu.buaa.crypto.access.parser;

/**
 * Created by Weiran Liu on 2016/7/20.
 */
public class PolicySyntaxException extends Exception {

}
