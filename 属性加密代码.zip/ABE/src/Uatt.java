public class Uatt {
    //该属性对应的编号
    public int number;
    //对应的时间限制
    public int[] timeLimit;

}
