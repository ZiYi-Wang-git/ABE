package sg.edu.ntu.sce.sands.crypto.dcpabe.ac;

public class OrGate extends InternalNode {
    private static final long serialVersionUID = 1L;

    @Override
    public String getName() {
        return "or";
    }
}