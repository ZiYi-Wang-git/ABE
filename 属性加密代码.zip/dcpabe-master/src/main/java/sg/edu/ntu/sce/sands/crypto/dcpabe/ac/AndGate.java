package sg.edu.ntu.sce.sands.crypto.dcpabe.ac;

public class AndGate extends InternalNode {
    private static final long serialVersionUID = 1L;

    @Override
    public String getName() {
        return "and";
    }
}